-- should be executed on primary database instance

ALTER SYSTEM SET db_securefile = ALWAYS;

CREATE OR REPLACE TYPE t_os_udaje IS OBJECT
(
	meno                 VARCHAR2(30),
	priezvisko           VARCHAR2(30),
	titul_pred           VARCHAR2(15),
	titul_za             VARCHAR2(15),
	tel_cislo            VARCHAR2(15),
	dat_narodenia        DATE 
);
/

ALTER TYPE t_os_udaje
ADD MEMBER FUNCTION cele_meno RETURN VARCHAR2;
/

CREATE OR REPLACE TYPE BODY t_os_udaje IS
    MEMBER FUNCTION cele_meno RETURN VARCHAR2 IS
    BEGIN
        RETURN TRIM(SELF.titul_pred || ' ' || SELF.meno || ' ' || SELF.priezvisko || ' ' || SELF.titul_za);
    END;
END;
/

CREATE OR REPLACE TYPE t_obec IS OBJECT
(
	kod_obce             NUMBER(6,0),
	nazov                VARCHAR2(35) 
);
/

CREATE OR REPLACE TYPE t_adresa IS OBJECT
(
	ulica                VARCHAR2(40),
	psc                  CHAR(5),
	obec                 REF t_obec
);
/

ALTER TYPE t_adresa
ADD MEMBER FUNCTION vypis RETURN VARCHAR2;
/

ALTER TYPE t_adresa
ADD MEMBER FUNCTION to_json RETURN VARCHAR2;
/

CREATE OR REPLACE TYPE BODY t_adresa IS
    MEMBER FUNCTION vypis RETURN VARCHAR2 IS
        v_nazov_obce VARCHAR2(35);
    BEGIN
        SELECT CASE
            WHEN SELF.obec IS DANGLING THEN '<<neznama obec>>'
            ELSE DEREF(SELF.obec).nazov
        END INTO v_nazov_obce
        FROM dual;
        
        RETURN SELF.ulica || ' ' || SELF.psc || ' ' || v_nazov_obce;
    END;
    
    MEMBER FUNCTION to_json RETURN VARCHAR2 IS
        v_nazov_obce VARCHAR2(35);
    BEGIN
        SELECT CASE
            WHEN SELF.obec IS DANGLING THEN NULL
            ELSE DEREF(SELF.obec).nazov
        END INTO v_nazov_obce
        FROM dual;
    
        RETURN JSON_OBJECT(
            'ulica' VALUE SELF.ulica,
            'psc' VALUE SELF.psc,
            'obec' VALUE v_nazov_obce
        );
    END;
END;
/

CREATE OR REPLACE TYPE t_prihlaseny_benefit_log IS OBJECT
(
    dosiah_pocet_jazd    NUMBER(4,0),
    dat_aktivacie        DATE,
    dat_pouzitia         DATE,
    pouzivatel           VARCHAR2(30),
    cas_akcie            DATE,
    typ_akcie            CHAR(1)
);
/

CREATE OR REPLACE TYPE t_prihlaseny_benefit_log_table IS TABLE OF t_prihlaseny_benefit_log;
/

CREATE TABLE taxisluzba
(
	ico                  NUMBER(8,0)  NOT NULL ,
	nazov                VARCHAR2(64)  NOT NULL ,
	adresa               t_adresa  NULL ,
	dat_licencia_od      DATE  DEFAULT sysdate  NOT NULL ,
	dat_licencia_do      DATE  NULL ,
    
    CHECK (adresa IS NULL OR adresa.ulica IS NOT NULL),
    CHECK (adresa IS NULL OR adresa.psc IS NOT NULL),
    CHECK (adresa IS NULL OR adresa.obec IS NOT NULL)
);

CREATE UNIQUE INDEX XPKtaxisluzba ON taxisluzba
(ico   ASC);

ALTER TABLE taxisluzba
	ADD CONSTRAINT  XPKtaxisluzba PRIMARY KEY (ico);

CREATE TABLE benefit
(
	id_benefit           INTEGER  NOT NULL ,
	taxisluzba           NUMBER(8,0)  NOT NULL ,
	potr_pocet_jazd      NUMBER(4,0)  NOT NULL  CONSTRAINT  nezaporny_potr_pocet_jazd_benefitu CHECK (potr_pocet_jazd >= 0),
	zlava                NUMBER(3,2)  NOT NULL  CONSTRAINT  zlava_benefitu_interval CHECK (zlava > 0 and zlava <= 1),
	typ                  CHAR(1)  DEFAULT 'V'  NOT NULL  CONSTRAINT  hodnota_typu_benefitu CHECK (typ in ('V', 'O')),
	dat_platnost_od      DATE  NOT NULL ,
	dat_platnost_do      DATE  NULL 
);

CREATE UNIQUE INDEX XPKbenefit ON benefit
(id_benefit   ASC);

ALTER TABLE benefit
	ADD CONSTRAINT  XPKbenefit PRIMARY KEY (id_benefit);

CREATE TABLE obec OF t_obec;

CREATE UNIQUE INDEX XPKobec ON obec
(kod_obce   ASC);

ALTER TABLE obec
	ADD CONSTRAINT  XPKobec PRIMARY KEY (kod_obce);

CREATE TABLE oblast
(
	id_oblast            INTEGER  NOT NULL ,
	nazov                VARCHAR2(50)  NOT NULL ,
	kod_obce             NUMBER(6,0)  NOT NULL 
);

CREATE UNIQUE INDEX XPKoblast ON oblast
(id_oblast   ASC);

ALTER TABLE oblast
	ADD CONSTRAINT  XPKoblast PRIMARY KEY (id_oblast);

CREATE TABLE typ_vozidla
(
	id_typ_vozidla       INTEGER  NOT NULL ,
	nazov                VARCHAR2(20)  NOT NULL ,
	skupina              VARCHAR2(3)  NOT NULL  CONSTRAINT  hodnota_skupiny_typu_vozidla CHECK (skupina in ('AM', 'A1', 'A2', 'A', 'B1', 'B', 'BE', 'C1', 'C1E', 'C', 'CE', 'D1', 'D1E', 'D', 'DE', 'T'))
);

CREATE UNIQUE INDEX XPKtyp_vozidla ON typ_vozidla
(id_typ_vozidla   ASC);

ALTER TABLE typ_vozidla
	ADD CONSTRAINT  XPKtyp_vozidla PRIMARY KEY (id_typ_vozidla);

CREATE TABLE vodic
(
	id_vodic             INTEGER  NOT NULL ,
	os_udaje             t_os_udaje  NOT NULL ,
	taxisluzba           NUMBER(8,0)  NOT NULL ,
	dat_nastup           DATE  DEFAULT sysdate  NOT NULL ,
	dat_odchod           DATE  NULL ,
	
    CHECK (os_udaje.meno IS NOT NULL),
    CHECK (os_udaje.priezvisko IS NOT NULL),
    CHECK (os_udaje.tel_cislo IS NOT NULL),
    CHECK (os_udaje.dat_narodenia IS NOT NULL)
);

CREATE UNIQUE INDEX XPKvodic ON vodic
(id_vodic   ASC);

ALTER TABLE vodic
	ADD CONSTRAINT  XPKvodic PRIMARY KEY (id_vodic);

CREATE TABLE opravnenie_vodica
(
	id_vodic             INTEGER  NOT NULL ,
	skupina              VARCHAR2(3)  NOT NULL  CONSTRAINT  hodnota_skupiny_opravnenia_vodica CHECK (skupina in ('AM', 'A1', 'A2', 'A', 'B1', 'B', 'BE', 'C1', 'C1E', 'C', 'CE', 'D1', 'D1E', 'D', 'DE', 'T')),
	dat_prve_udelenie    DATE  NOT NULL ,
	dat_platnost_do      DATE  NOT NULL 
);

CREATE UNIQUE INDEX XPKopravnenie_vodica ON opravnenie_vodica
(id_vodic   ASC,skupina   ASC);

ALTER TABLE opravnenie_vodica
	ADD CONSTRAINT  XPKopravnenie_vodica PRIMARY KEY (id_vodic,skupina);

CREATE TABLE vozidlo
(
	id_vozidlo           INTEGER  NOT NULL ,
	ecv                  CHAR(7)  NOT NULL ,
	taxisluzba           NUMBER(8,0)  NOT NULL ,
	id_typ_vozidla       INTEGER  NOT NULL ,
	znacka               VARCHAR2(20)  NULL ,
	kapacita             NUMBER(4,0)  NOT NULL  CONSTRAINT  kladna_kapacita_vozidla CHECK (kapacita > 0),
	dat_evidencie        DATE  NULL ,
	dat_zaradenie        DATE  DEFAULT sysdate  NOT NULL ,
	dat_vyradenie        DATE  NULL ,
    fotka                BLOB  NULL
) lob (fotka) store as securefile;

CREATE UNIQUE INDEX XPKvozidlo ON vozidlo
(id_vozidlo   ASC);

ALTER TABLE vozidlo
	ADD CONSTRAINT  XPKvozidlo PRIMARY KEY (id_vozidlo);

CREATE TABLE tarifa
(
	nastup_oblast        INTEGER  NOT NULL ,
	vystup_oblast        INTEGER  NOT NULL ,
	taxisluzba           NUMBER(8,0)  NOT NULL ,
	id_typ_vozidla       INTEGER  NOT NULL ,
	dat_platnost_od      DATE  NOT NULL ,
	cena                 NUMBER(6,2)  NOT NULL  CONSTRAINT  nezaporna_cena_tarify CHECK (cena >= 0),
	dat_platnost_do      DATE  NULL 
);

CREATE UNIQUE INDEX XPKtarifa ON tarifa
(nastup_oblast   ASC,vystup_oblast   ASC,taxisluzba   ASC,id_typ_vozidla   ASC,dat_platnost_od   ASC);

ALTER TABLE tarifa
	ADD CONSTRAINT  XPKtarifa PRIMARY KEY (nastup_oblast,vystup_oblast,taxisluzba,id_typ_vozidla,dat_platnost_od);

CREATE TABLE zakaznik
(
	id_zakaznik          INTEGER  NOT NULL ,
	os_udaje             t_os_udaje  NOT NULL ,
	adresa               t_adresa  NULL ,
	email                VARCHAR2(100)  NULL ,
	dat_registracie      DATE  DEFAULT sysdate  NOT NULL ,
	dat_ukoncenia        DATE  NULL ,
    
    CHECK (os_udaje.meno IS NOT NULL),
    CHECK (os_udaje.priezvisko IS NOT NULL),
    CHECK (os_udaje.tel_cislo IS NOT NULL),
    CHECK (os_udaje.dat_narodenia IS NOT NULL),
    
    CHECK (adresa IS NULL OR adresa.ulica IS NOT NULL),
    CHECK (adresa IS NULL OR adresa.psc IS NOT NULL),
    CHECK (adresa IS NULL OR adresa.obec IS NOT NULL)
);

CREATE UNIQUE INDEX XPKzakaznik ON zakaznik
(id_zakaznik   ASC);

ALTER TABLE zakaznik
	ADD CONSTRAINT  XPKzakaznik PRIMARY KEY (id_zakaznik);

CREATE TABLE prihlaseny_benefit
(
	id_zakaznik          INTEGER  NOT NULL ,
	id_benefit           INTEGER  NOT NULL ,
	dat_prihlasenia      DATE  DEFAULT sysdate  NOT NULL ,
	dosiah_pocet_jazd    NUMBER(4,0)  NOT NULL  CONSTRAINT  nezaporny_dosiah_pocet_jazd_benefitu CHECK (dosiah_pocet_jazd >= 0),
	dat_aktivacie        DATE  NULL ,
	dat_pouzitia         DATE  NULL ,
    historia             t_prihlaseny_benefit_log_table
) NESTED TABLE historia STORE AS prihlaseny_benefit_log;

CREATE UNIQUE INDEX XPKprihlaseny_benefit ON prihlaseny_benefit
(id_zakaznik   ASC,id_benefit   ASC,dat_prihlasenia   ASC);

ALTER TABLE prihlaseny_benefit
	ADD CONSTRAINT  XPKprihlaseny_benefit PRIMARY KEY (id_zakaznik,id_benefit,dat_prihlasenia);

ALTER TABLE prihlaseny_benefit_log ADD CHECK (dosiah_pocet_jazd IS NOT NULL);
ALTER TABLE prihlaseny_benefit_log ADD CHECK (pouzivatel IS NOT NULL);
ALTER TABLE prihlaseny_benefit_log ADD CHECK (cas_akcie IS NOT NULL);
ALTER TABLE prihlaseny_benefit_log ADD CHECK (typ_akcie IS NOT NULL);
ALTER TABLE prihlaseny_benefit_log ADD CONSTRAINT prihlaseny_benefit_log_hodnota_typu_akcie CHECK (typ_akcie IN ('I', 'U', 'D'));

CREATE TABLE jazda
(
	id_vozidlo           INTEGER  NOT NULL ,
	id_vodic             INTEGER  NOT NULL ,
	dat_zaciatok         DATE  NOT NULL ,
	dat_koniec           DATE  NULL ,
	id_zakaznik          INTEGER  NULL ,
	nastup_oblast        INTEGER  NOT NULL ,
	vystup_oblast        INTEGER  NOT NULL ,
	cena                 NUMBER(6,2)  NOT NULL  CONSTRAINT  nezaporna_cena_jazdy CHECK (cena >= 0)
);

CREATE UNIQUE INDEX XPKjazda ON jazda
(id_vozidlo   ASC,id_vodic   ASC,dat_zaciatok   ASC);

ALTER TABLE jazda
	ADD CONSTRAINT  XPKjazda PRIMARY KEY (id_vozidlo,id_vodic,dat_zaciatok);

ALTER TABLE benefit
	ADD (
CONSTRAINT R_26 FOREIGN KEY (taxisluzba) REFERENCES taxisluzba (ico));

ALTER TABLE oblast
	ADD (
CONSTRAINT R_13 FOREIGN KEY (kod_obce) REFERENCES obec (kod_obce));

ALTER TABLE vodic
	ADD (
CONSTRAINT R_10 FOREIGN KEY (taxisluzba) REFERENCES taxisluzba (ico));

ALTER TABLE opravnenie_vodica
	ADD (
CONSTRAINT R_32 FOREIGN KEY (id_vodic) REFERENCES vodic (id_vodic));

ALTER TABLE vozidlo
	ADD (
CONSTRAINT R_1 FOREIGN KEY (taxisluzba) REFERENCES taxisluzba (ico));

ALTER TABLE vozidlo
	ADD (
CONSTRAINT R_6 FOREIGN KEY (id_typ_vozidla) REFERENCES typ_vozidla (id_typ_vozidla));

ALTER TABLE tarifa
	ADD (
CONSTRAINT R_16 FOREIGN KEY (taxisluzba) REFERENCES taxisluzba (ico));

ALTER TABLE tarifa
	ADD (
CONSTRAINT R_18 FOREIGN KEY (id_typ_vozidla) REFERENCES typ_vozidla (id_typ_vozidla));

ALTER TABLE tarifa
	ADD (
CONSTRAINT R_14 FOREIGN KEY (nastup_oblast) REFERENCES oblast (id_oblast));

ALTER TABLE tarifa
	ADD (
CONSTRAINT R_15 FOREIGN KEY (vystup_oblast) REFERENCES oblast (id_oblast));

ALTER TABLE prihlaseny_benefit
	ADD (
CONSTRAINT R_38 FOREIGN KEY (id_zakaznik) REFERENCES zakaznik (id_zakaznik));

ALTER TABLE prihlaseny_benefit
	ADD (
CONSTRAINT R_41 FOREIGN KEY (id_benefit) REFERENCES benefit (id_benefit));

ALTER TABLE jazda
	ADD (
CONSTRAINT R_21 FOREIGN KEY (id_vozidlo) REFERENCES vozidlo (id_vozidlo));

ALTER TABLE jazda
	ADD (
CONSTRAINT R_24 FOREIGN KEY (id_vodic) REFERENCES vodic (id_vodic));

ALTER TABLE jazda
	ADD (
CONSTRAINT R_25 FOREIGN KEY (id_zakaznik) REFERENCES zakaznik (id_zakaznik) ON DELETE SET NULL);

ALTER TABLE jazda
	ADD (
CONSTRAINT R_36 FOREIGN KEY (nastup_oblast) REFERENCES oblast (id_oblast));

ALTER TABLE jazda
	ADD (
CONSTRAINT R_37 FOREIGN KEY (vystup_oblast) REFERENCES oblast (id_oblast));
