-- should be executed on secondary database instance

CREATE TABLE kontrola_vozidla
(
	id_vozidlo           INTEGER  NOT NULL ,
	typ_kontroly         CHAR(1)  NOT NULL  CONSTRAINT  hodnota_typu_kontroly_vozidla CHECK (typ_kontroly in ('T', 'E')),
	dat_kontroly         DATE  DEFAULT sysdate  NOT NULL ,
	dat_platnost_do      DATE  NULL 
);

CREATE UNIQUE INDEX XPKkontrola_vozidla ON kontrola_vozidla
(id_vozidlo   ASC,typ_kontroly   ASC,dat_kontroly   ASC);

ALTER TABLE kontrola_vozidla
	ADD CONSTRAINT  XPKkontrola_vozidla PRIMARY KEY (id_vozidlo,typ_kontroly,dat_kontroly);
