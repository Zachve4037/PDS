create or replace function prienik_intervalov(
    p_a_od date, p_a_do date,
    p_b_od date, p_b_do date
)
return char
deterministic
is
    v_a_od date := nvl(p_a_od, date '0001-01-01');
    v_b_od date := nvl(p_b_od, date '0001-01-01');
    v_vysledok char := 'F';
begin
    if (v_b_od >= v_a_od and (p_a_do is null or v_b_od <= p_a_do))
      or (v_a_od >= v_b_od and (p_b_do is null or v_a_od <= p_b_do)) then
        v_vysledok := 'T';
    end if;
    
    return v_vysledok;
end;
/
