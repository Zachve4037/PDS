create directory wallet_dir as 'wallet';

begin
    dbms_cloud.create_credential(
        credential_name => 'WALLET_BUCKET_CRED',
        username => 'zemcik.erik@gmail.com',
        password => '5a5O}DU83R;uhFE5#-xh'
    );
end;
/

declare
    type t_files is table of varchar2(20);
    v_files t_files := t_files('cwallet.sso');
begin
    for i in v_files.first .. v_files.last loop
        dbms_cloud.get_object(
            credential_name => 'WALLET_BUCKET_CRED',
            object_uri => 'https://fr9xrpjci0ds.objectstorage.eu-frankfurt-1.oci.customer-oci.com/n/fr9xrpjci0ds/b/wallets/o/' || v_files(i),
            directory_name => 'WALLET_DIR'
        );
    end loop;
end;
/

begin
    dbms_cloud.create_credential(
        credential_name => 'SECONDARY_CRED',
        username => 'TAXISLUZBA',
        password => 'VY7542uHhyrZQs22'
    );
end;
/

begin
    dbms_cloud_admin.create_database_link(
        db_link_name => 'SECONDARY',
        hostname => 'adb.eu-frankfurt-1.oraclecloud.com', 
        port => '1522',
        service_name => 'g77f423e6d25f8e_taxisluzba2_high.adb.oraclecloud.com',
        credential_name => 'SECONDARY_CRED',
        directory_name => 'WALLET_DIR',
        public_link => true,
        private_target => false
    );
end;
/
