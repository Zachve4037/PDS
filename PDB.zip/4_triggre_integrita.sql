create or replace trigger t_benefit_datum_interval
before insert or update on benefit
for each row
when (new.dat_platnost_do is not null and new.dat_platnost_od > new.dat_platnost_do)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_jazda_zakaz_uprav_pk
before update on jazda
for each row
when (old.id_vozidlo <> new.id_vozidlo or old.id_vodic <> new.id_vodic or old.dat_zaciatok <> new.dat_zaciatok)
begin
    raise_application_error(-20011, 'Zakaz menenia PK existujucej jazdy!');
end;
/

create or replace trigger t_jazda_rovnaka_taxisluzba
before insert on jazda
for each row
declare
    v_ico_vodic taxisluzba.ico%type;
    v_ico_vozidlo taxisluzba.ico%type;
begin
    select taxisluzba into v_ico_vodic
    from vodic
    where id_vodic = :new.id_vodic;
    
    select taxisluzba into v_ico_vozidlo
    from vozidlo
    where id_vozidlo = :new.id_vozidlo;
    
    if v_ico_vodic <> v_ico_vozidlo then
        raise_application_error(-20001, 'Vozidlo a vodic musia patrit rovnakej taxisluzbe!');
    end if;
end;
/

create or replace trigger t_jazda_aktivny_vodic
before insert on jazda
for each row
declare
    v_dat_nastup date;
    v_dat_odchod date;
begin
    select dat_nastup, dat_odchod into v_dat_nastup, v_dat_odchod
    from vodic
    where id_vodic = :new.id_vodic;
    
    if v_dat_nastup > :new.dat_zaciatok or (v_dat_odchod is not null and (:new.dat_koniec is null or v_dat_odchod < :new.dat_koniec)) then
        raise_application_error(-20003, 'Jazdu moze realizovat iba aktivny vodic!');
    end if;
end;
/

create or replace trigger t_jazda_aktivne_vozidlo
before insert on jazda
for each row
declare
    v_dat_zaradenie date;
    v_dat_vyradenie date;
begin
    select dat_zaradenie, dat_vyradenie into v_dat_zaradenie, v_dat_vyradenie
    from vozidlo
    where id_vozidlo = :new.id_vozidlo;
    
    if v_dat_zaradenie > :new.dat_zaciatok or (v_dat_vyradenie is not null and (:new.dat_koniec is null or v_dat_vyradenie < :new.dat_koniec)) then
        raise_application_error(-20004, 'Jazda sa moze realizovat iba s aktivnym vozidlom!');
    end if;
end;
/

create or replace trigger t_jazda_aktivny_zakaznik
before insert or update on jazda
for each row
when (new.id_zakaznik is not null)
declare
    v_dat_registracie date;
    v_dat_ukoncenia date;
begin
    select dat_registracie, dat_ukoncenia into v_dat_registracie, v_dat_ukoncenia
    from zakaznik
    where id_zakaznik = :new.id_zakaznik;
    
    if v_dat_registracie > :new.dat_zaciatok or (v_dat_ukoncenia is not null and (:new.dat_koniec is null or v_dat_ukoncenia < :new.dat_koniec)) then
        raise_application_error(-20023, 'Jazda sa moze realizovat iba s aktivnym zakaznikom!');
    end if;
end;
/

create or replace trigger t_v_jazda_insert_kontrola_prienikov
instead of insert on v_jazda
declare
    v_prienik char;
begin
    select case when exists (
        select 'x'
        from jazda
        where (id_vodic = :new.id_vodic or id_vozidlo = :new.id_vozidlo)
          and prienik_intervalov(dat_zaciatok, dat_koniec, :new.dat_zaciatok, :new.dat_koniec) = 'T'
    ) then 'T' else 'F' end into v_prienik
    from dual;
    
    if v_prienik = 'T' then
        raise_application_error(-20020, 'Jazda musi mat v danom case neobsadeneho vodica alebo vozidlo!');
    end if;
    
    insert into jazda
    values (:new.id_vozidlo, :new.id_vodic, :new.dat_zaciatok, :new.dat_koniec, :new.id_zakaznik, :new.nastup_oblast, :new.vystup_oblast, :new.cena);
end;
/

create or replace trigger t_jazda_datum_interval
before insert or update on jazda
for each row
when (new.dat_koniec is not null and new.dat_zaciatok > new.dat_koniec)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_kontrola_vozidla_datum_interval
before insert or update on kontrola_vozidla
for each row
when (new.dat_platnost_do is not null and new.dat_kontroly > new.dat_platnost_do)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_opravnenie_vodica_datum_interval
before insert or update on opravnenie_vodica
for each row
when (new.dat_prve_udelenie > new.dat_platnost_do)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_prihlaseny_benefit_aktivacia_interval
before insert or update on prihlaseny_benefit
for each row
when (new.dat_aktivacie is not null and new.dat_prihlasenia > new.dat_aktivacie)
begin
    raise_application_error(-20002, 'Prihlaseny benefit sa da aktivovat az po prihlaseni!');
end;
/

create or replace trigger t_prihlaseny_benefit_pouzitie_iba_po_aktivacii
before insert or update on prihlaseny_benefit
for each row
when (new.dat_pouzitia is not null and (new.dat_aktivacie is null or new.dat_aktivacie > new.dat_pouzitia))
begin
    raise_application_error(-20002, 'Prihlaseny benefit sa da pouzit iba po aktivacii!');
end;
/

create or replace trigger t_prihlaseny_benefit_platnost
before insert or update on prihlaseny_benefit
for each row
declare
    v_dat_platnost_od date;
    v_dat_platnost_do date;
begin
    select dat_platnost_od, dat_platnost_do into v_dat_platnost_od, v_dat_platnost_do
    from benefit
    where id_benefit = :new.id_benefit;
    
    if :new.dat_prihlasenia > v_dat_platnost_do or :new.dat_aktivacie > v_dat_platnost_do
      or :new.dat_pouzitia > v_dat_platnost_do or :new.dat_prihlasenia < v_dat_platnost_od then
        raise_application_error(-20009, 'Benefit sa da menit iba v ramci jeho platnosti!');
    end if;
end;
/

create or replace trigger t_tarifa_zakaz_uprav_okrem_ukoncenie_platnosti
before update on tarifa
for each row
when (old.nastup_oblast <> new.nastup_oblast or old.vystup_oblast <> new.vystup_oblast
    or old.taxisluzba <> new.taxisluzba or old.id_typ_vozidla <> new.id_typ_vozidla
    or old.dat_platnost_od <> new.dat_platnost_od or old.cena <> new.cena
    or (old.dat_platnost_do is not null and (old.dat_platnost_do is null or old.dat_platnost_do <> new.dat_platnost_do)))
begin
    raise_application_error(-20007, 'Zakaz menenia tarify okrem ukoncenia!');
end;
/

create or replace trigger t_tarifa_datum_interval
before insert or update on tarifa
for each row
when (new.dat_platnost_do is not null and new.dat_platnost_od > new.dat_platnost_do)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_v_tarifa_insert_kontrola_prienikov
instead of insert on v_tarifa
declare
    v_prienik char;
begin
    select case when exists (
        select 'x'
        from tarifa
        where nastup_oblast = :new.nastup_oblast
          and vystup_oblast = :new.vystup_oblast
          and taxisluzba = :new.taxisluzba
          and id_typ_vozidla = :new.id_typ_vozidla
          and prienik_intervalov(dat_platnost_od, dat_platnost_do, :new.dat_platnost_od, :new.dat_platnost_do) = 'T'
    ) then 'T' else 'F' end into v_prienik
    from dual;
    
    if v_prienik = 'T' then
        raise_application_error(-20008, 'Na toto obdobie existuje uz platna tarifa!');
    end if;
    
    insert into tarifa
    values (:new.nastup_oblast, :new.vystup_oblast, :new.taxisluzba, :new.id_typ_vozidla, :new.dat_platnost_od, :new.cena, :new.dat_platnost_do);
end;
/

create or replace trigger t_taxisluzba_datum_interval
before insert or update on taxisluzba
for each row
when (new.dat_licencia_do is not null and new.dat_licencia_od > new.dat_licencia_do)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_vodic_datum_interval
before insert or update on vodic
for each row
when (new.dat_odchod is not null and new.dat_nastup > new.dat_odchod)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_vodic_odchod_po_jazdach
before update on vodic
for each row
when (new.dat_odchod is not null)
declare
    v_prienik char;
begin
    select case when exists (
        select 'x'
        from jazda
        where id_vodic = :new.id_vodic
          and (dat_koniec is null or dat_koniec > :new.dat_odchod)
    ) then 'T' else 'F' end into v_prienik
    from dual;
    
    if v_prienik = 'T' then
        raise_application_error(-20006, 'Vodic ma v zadanom case este jazdu!');
    end if;
end;
/

create or replace trigger t_vodic_kaskada_opravneni
before delete on vodic
for each row
begin
    delete from opravnenie_vodica
    where id_vodic = :old.id_vodic;
end;
/

create or replace trigger t_vozidlo_vyradenie_interval
before insert or update on vozidlo
for each row
when (new.dat_vyradenie is not null and new.dat_zaradenie > new.dat_vyradenie)
begin
    raise_application_error(-20002, 'Vozidlo moze byt vyradene az po zaradeni!');
end;
/

create or replace trigger t_vozidlo_zaradenie_interval
before insert or update on vozidlo
for each row
when (new.dat_evidencie is not null and new.dat_evidencie > new.dat_zaradenie)
begin
    raise_application_error(-20002, 'Vozidlo musi byt zaradene po evidencii!');
end;
/

create or replace trigger t_vozidlo_vyradenie_po_jazdach
before update on vozidlo
for each row
when (new.dat_vyradenie is not null)
declare
    v_prienik char;
begin
    select case when exists (
        select 'x'
        from jazda
        where id_vozidlo = :new.id_vozidlo
          and (dat_koniec is null or dat_koniec > :new.dat_vyradenie)
    ) then 'T' else 'F' end into v_prienik
    from dual;
    
    if v_prienik = 'T' then
        raise_application_error(-20005, 'Vozidlo ma v zadanom case este jazdu!');
    end if;
end;
/

create or replace trigger t_vozidlo_kaskada_kontroly
before delete on vozidlo
for each row
begin
    delete from kontrola_vozidla
    where id_vozidlo = :old.id_vozidlo;
end;
/

create or replace trigger t_zakaznik_datum_interval
before insert or update on zakaznik
for each row
when (new.dat_ukoncenia is not null and new.dat_registracie > new.dat_ukoncenia)
begin
    raise_application_error(-20002, 'Zacitatocny datum musi byt pred konecnym datumom!');
end;
/

create or replace trigger t_zakaznik_ukoncenie_registracie_po_jazdach
before update on zakaznik
for each row
when (new.dat_ukoncenia is not null)
declare
    v_prienik char;
begin
    select case when exists (
        select 'x'
        from jazda
        where id_zakaznik = :new.id_zakaznik
          and (dat_koniec is null or dat_koniec > :new.dat_ukoncenia)
    ) then 'T' else 'F' end into v_prienik
    from dual;
    
    if v_prienik = 'T' then
        raise_application_error(-20021, 'Zakaznik ma v zadanom case este jazdu!');
    end if;
end;
/
