create or replace view v_tarifa as
select * from tarifa;

create or replace view v_jazda as
select * from jazda;


create view kontrola_vozidla as
select * from kontrola_vozidla@secondary;

create or replace trigger kontrola_vozidla_insert
instead of insert on kontrola_vozidla
for each row
declare
    v_existuje_vozidlo char;
begin
    select case when exists (
        select 'x'
        from vozidlo
        where id_vozidlo = :new.id_vozidlo
    ) then 'T' else 'F' end into v_existuje_vozidlo
    from dual;
    
    if v_existuje_vozidlo = 'F' then
        raise_application_error(-20009, 'Kontrola vozidla pre neexistujuce vozidlo');
    end if;
    
    insert into kontrola_vozidla@secondary
    values (:new.id_vozidlo, :new.typ_kontroly, :new.dat_kontroly, :new.dat_platnost_do);
end;
/

create or replace trigger kontrola_vozidla_update
instead of update on kontrola_vozidla
for each row
declare
    v_existuje_vozidlo char;
begin
    if :old.id_vozidlo <> :new.id_vozidlo then
        select case when exists (
            select 'x'
            from vozidlo
            where id_vozidlo = :new.id_vozidlo
        ) then 'T' else 'F' end into v_existuje_vozidlo
        from dual;
        
        if v_existuje_vozidlo = 'F' then
            raise_application_error(-20009, 'Kontrola vozidla pre neexistujuce vozidlo');
        end if;
    end if;
    
    update kontrola_vozidla@secondary
    set
        id_vozidlo = :new.id_vozidlo,
        typ_kontroly = :new.typ_kontroly,
        dat_kontroly = :new.dat_kontroly,
        dat_platnost_do = :new.dat_platnost_do
    where id_vozidlo = :old.id_vozidlo;
end;
/


create view zakaznik_apex as
select
    z.id_zakaznik,
    z.os_udaje.meno as meno,
    z.os_udaje.priezvisko as priezvisko,
    z.os_udaje.titul_pred as titul_pred,
    z.os_udaje.titul_za as titul_za,
    z.os_udaje.tel_cislo as tel_cislo,
    z.os_udaje.dat_narodenia as dat_narodenia,
    z.adresa.ulica as ulica,
    z.adresa.psc as psc,
    case when z.adresa.obec is dangling then null else deref(z.adresa.obec).kod_obce end as kod_obce,
    email,
    dat_registracie,
    dat_ukoncenia
from zakaznik z;

create or replace trigger zakaznik_apex_insert
instead of insert on zakaznik_apex
for each row
declare
    v_adresa t_adresa := null;
    v_obec ref t_obec;
begin
    if :new.ulica is not null and :new.psc is not null and :new.kod_obce is not null then
        select ref(o) into v_obec
        from obec o
        where kod_obce = :new.kod_obce;
        
        v_adresa := t_adresa(:new.ulica, :new.psc, v_obec);
    end if;
    
    insert into zakaznik values (
        (select max(id_zakaznik) + 1 from zakaznik),
        t_os_udaje(:new.meno, :new.priezvisko, :new.titul_pred, :new.titul_za, :new.tel_cislo, :new.dat_narodenia),
        v_adresa,
        :new.email,
        :new.dat_registracie,
        :new.dat_ukoncenia
    );
end;
/

create or replace trigger zakaznik_apex_update
instead of update on zakaznik_apex
for each row
declare
    v_adresa t_adresa := null;
    v_obec ref t_obec;
begin
    if :new.ulica is not null and :new.psc is not null and :new.kod_obce is not null then
        select ref(o) into v_obec
        from obec o
        where kod_obce = :new.kod_obce;
        
        v_adresa := t_adresa(:new.ulica, :new.psc, v_obec);
    end if;
    
    update zakaznik
    set id_zakaznik = :new.id_zakaznik,
        os_udaje = t_os_udaje(:new.meno, :new.priezvisko, :new.titul_pred, :new.titul_za, :new.tel_cislo, :new.dat_narodenia),
        adresa = v_adresa,
        email = :new.email,
        dat_registracie = :new.dat_registracie,
        dat_ukoncenia = :new.dat_ukoncenia
    where id_zakaznik = :old.id_zakaznik;
end;
/

create or replace trigger zakaznik_apex_delete
instead of delete on zakaznik_apex
for each row
begin
    delete from zakaznik
    where id_zakaznik = :old.id_zakaznik;
end;
/


create view taxisluzba_apex as
select
    t.ico,
    t.nazov,
    t.adresa.ulica as ulica,
    t.adresa.psc as psc,
    case when t.adresa.obec is dangling then null else deref(t.adresa.obec).kod_obce end as kod_obce,
    t.dat_licencia_od,
    t.dat_licencia_do
from taxisluzba t;

create or replace trigger taxisluzba_apex_insert
instead of insert on taxisluzba_apex
for each row
declare
    v_adresa t_adresa := null;
    v_obec ref t_obec;
begin
    if :new.ulica is not null and :new.psc is not null and :new.kod_obce is not null then
        select ref(o) into v_obec
        from obec o
        where kod_obce = :new.kod_obce;
        
        v_adresa := t_adresa(:new.ulica, :new.psc, v_obec);
    end if;
    
    insert into taxisluzba
    values (:new.ico, :new.nazov, v_adresa, :new.dat_licencia_od, :new.dat_licencia_do);
end;
/

create or replace trigger taxisluzba_apex_update
instead of update on taxisluzba_apex
for each row
declare
    v_adresa t_adresa := null;
    v_obec ref t_obec;
begin
    if :new.ulica is not null and :new.psc is not null and :new.kod_obce is not null then
        select ref(o) into v_obec
        from obec o
        where kod_obce = :new.kod_obce;
        
        v_adresa := t_adresa(:new.ulica, :new.psc, v_obec);
    end if;
    
    update taxisluzba
    set
        ico = :new.ico,
        nazov = :new.nazov,
        adresa = v_adresa,
        dat_licencia_od = :new.dat_licencia_od,
        dat_licencia_do = :new.dat_licencia_do
    where ico = :old.ico;
end;
/

create or replace trigger taxisluzba_apex_delete
instead of delete on taxisluzba_apex
for each row
begin
    delete from taxisluzba
    where ico = :old.ico;
end;
/


create view vodic_apex as
select
    v.id_vodic,
    v.os_udaje.meno as meno,
    v.os_udaje.priezvisko as priezvisko,
    v.os_udaje.titul_pred as titul_pred,
    v.os_udaje.titul_za as titul_za,
    v.os_udaje.tel_cislo as tel_cislo,
    v.os_udaje.dat_narodenia as dat_narodenia,
    v.taxisluzba,
    v.dat_nastup,
    v.dat_odchod
from vodic v;

create or replace trigger vodic_apex_insert
instead of insert on vodic_apex
for each row
begin
    insert into vodic
    values (
        :new.id_vodic,
        t_os_udaje(
            :new.meno,
            :new.priezvisko,
            :new.titul_pred,
            :new.titul_za,
            :new.tel_cislo,
            :new.dat_narodenia
        ),
        :new.taxisluzba,
        :new.dat_nastup,
        :new.dat_odchod
    );
end;
/

create or replace trigger vodic_apex_update
instead of update on vodic_apex
for each row
begin
    update vodic
    set
        id_vodic = :new.id_vodic,
        os_udaje = t_os_udaje(
            :new.meno,
            :new.priezvisko,
            :new.titul_pred,
            :new.titul_za,
            :new.tel_cislo,
            :new.dat_narodenia
        ),
        taxisluzba = :new.taxisluzba,
        dat_nastup = :new.dat_nastup,
        dat_odchod = :new.dat_odchod
    where id_vodic = :old.id_vodic;
end;
/
